# 🌙 Moonlight Exchange — Complete Production Guide

**Genre:** Magical realism / slice-of-life romance  
**Model:** Z-Anime (SeeSee21) for images, LTX 2.3 + Prompt Relay for video  
**Total Scenes:** 10  
**Estimated Total Video:** ~3.5 minutes

---

## Characters

### 1. Mei — The Illustrator (protagonist)
- 19-year-old, petite, messy chestnut hair tied with a faded blue ribbon
- Wears an oversized cream knit cardigan over a simple white shirt, denim skirt, knee-high socks, scuffed loafers
- Always carries a worn sketchbook and a cup of boba tea
- Gentle, observant, a little lonely — warm amber eyes
- Secret: she sees emotions as colored light (nostalgia = gold, sadness = blue, joy = pink)

### 2. Ren — The Antique Shop Owner
- 21-year-old, tall and lean, dark messy hair with a silver chain necklace
- Wears a charcoal button-down with rolled sleeves, dark jeans, fingerless gloves on his left hand
- Calm exterior, dry humor, hides a lot behind a careful smile
- Cool grey eyes — almost unreadable
- Secret: he can hear the "memories" of old objects when he touches them

### 3. Pudding — The Shop Cat
- A chubby orange tabby cat with one white paw, always sleeping in sunlight
- Appears in most scenes as a silent bridge between Mei and Ren

---

## Character Image Prompts

### Mei — Full Body
```
A full-body illustration of a 19-year-old anime girl named Mei, petite build, messy chestnut hair tied with a faded blue ribbon, warm amber eyes, wearing an oversized cream knit cardigan over a white cotton shirt, blue denim skirt, navy knee-high socks, and scuffed brown loafers. She holds a worn sketchbook in one arm and a plastic boba tea cup in her other hand. Soft natural lighting, gentle expression, standing in a sunlit street, high quality anime key visual, fine line work.
```

### Mei — Portrait
```
Detailed anime portrait of Mei, a 19-year-old girl with messy chestnut hair and a faded blue ribbon, warm amber eyes looking thoughtfully to the side, soft natural skin shading, gentle slight smile, wearing an oversized cream cardigan, shallow depth of field, warm afternoon lighting, professional anime illustration quality, fine line work.
```

### Ren — Full Body
```
A full-body illustration of a 21-year-old anime boy named Ren, tall and lean build, dark messy hair with a silver chain necklace, cool grey eyes, wearing a charcoal button-down shirt with sleeves rolled to the elbows, dark jeans, fingerless gloves on his left hand. He stands casually with one hand in his pocket, calm unreadable expression, soft side lighting, high quality anime character design, fine line work.
```

### Ren — Portrait
```
Detailed anime portrait of Ren, a 21-year-old boy with dark messy hair, a silver chain necklace visible at his collar, cool grey eyes with a subtle guarded expression, wearing a charcoal button-down with sleeves rolled up, soft dramatic side lighting, shallow depth of field, professional anime illustration quality.
```

### Pudding the Cat
```
An adorable chubby orange tabby cat with one white front paw, sitting in a pool of warm sunlight, eyes half-closed in sleepy contentment, soft fluffy fur rendering, anime style, cozy atmosphere, detailed fur texture.
```

---

## Background Scene Prompts

### Scene 1 — The Discovered Shop (Exterior)
```
Anime illustration of a narrow old Japanese street at dusk, a small antique shop with wooden shutters and a faded hand-painted sign reading "Moonlight Exchange." Warm amber street lamps cast a soft glow through evening mist, hanging lanterns sway gently, potted plants and bicycle parked near the entrance. Atmospheric, Makoto Shinkai style background, highly detailed, wallpaper quality.
```

### Scene 2 — Inside the Antique Shop
```
Anime interior illustration of a cozy cluttered antique shop at golden hour. Tall wooden shelves filled with vintage items — music boxes, old cameras, porcelain figurines, stacks of books. A large wooden counter with a brass lamp casting warm pool of light. Sunlight streams through a large front window. Dust motes visible in the light. An orange cat sleeps on the counter. Warm gold and brown palette, detailed environment art.
```

### Scene 3 — Shop Counter Close-up
```
Close-up anime illustration of a worn wooden antique shop counter, warm brass lamp light illuminating the scene. An old brass key rests on the wood, surrounded by scattered antique trinkets — a pocket watch, a small glass vial, dried pressed flowers. Warm intimate atmosphere, shallow depth of field, detailed texture on the wood grain, high quality anime still image.
```

### Scene 4 — Mei's Apartment
```
Anime interior illustration of a small cozy artist's apartment at sunset. A wooden desk sits by the window with a warm desk lamp, scattered loose sketches, a set of colorful markers, and a half-empty boba tea cup. The walls are covered with vibrant anime-style illustrations pinned up in a collage. A small green potted plant sits on the windowsill, light blue curtains billowing gently in the breeze. Warm orange and lavender sunlight streams through the window, casting long soft shadows across the wooden floor. A low bookshelf in the corner is stacked with manga and art books. Cozy lived-in atmosphere, highly detailed background art, wallpaper quality, Makoto Shinkai style lighting.
```

### Scene 5 — Rooftop at Night
```
Wide anime illustration of a rooftop overlooking an old Japanese district at night. The rooftop is concrete with a rusty metal railing, a small abandoned potted plant in the corner, and scattered loose bricks. The city stretches far below in a sea of tiny warm lights against a deep blue starlit sky. A crescent moon hangs softly in the upper right with scattered stars. The old district below features traditional tile roofs mixed with low modern buildings. Cinematic wide shot, atmospheric, emotional, Studio Ghibli inspired night scene, highly detailed background art, wallpaper quality.
```

### Scene 6 — Workbench Detail
```
Close-up anime illustration of an antique repair workbench under a focused brass desk lamp. An opened brass music box with intricate gears and a tiny rotating ballerina visible inside. A small dark velvet-lined tray holds tiny screws, tweezers, and a precision screwdriver. A soft cotton cloth, a magnifying glass, and scattered handwritten repair notes with sketches lie beside them. Warm amber light from the lamp creates dramatic pool of light and deep shadows on the dark scratched wood surface. Intimate detailed scene, high quality anime still frame, shallow depth of field.
```

### Scene 7 — Rainy Street
```
Anime illustration of the old narrow Japanese street in heavy rain at dusk. The cobblestone street is slick and highly reflective, rain puddles mirroring the warm amber glow of hanging street lamps and shop windows. Raindrops streak diagonally across the frame in sharp focus. In the background, the antique shop's warm golden window light stands out against the blue-grey downpour. Wet wooden shutters, dripping eaves, a parked bicycle with rain running off it. Blue-grey cool atmosphere contrasted with warm golden shop light. Cinematic, emotional, highly detailed, Makoto Shinkai rain scene quality.
```

### Scene 8 — The Attic
```
Anime interior illustration of a dusty attic in an old wooden building at afternoon. A single rectangular skylight in the sloped roof casts dramatic golden shafts of light through the air, dust motes floating thickly in the beams. An old locked wooden chest with iron bands sits in the center of the frame, surrounded by stacked fabric-covered trunks, an old rocking chair, and cobwebs in the corners. Warm mysterious atmosphere, light rays cutting through darkness, high contrast between bright and shadow areas, highly detailed environment art, wallpaper quality.
```

### Scene 9 — Rooftop at Sunrise
```
Wide anime illustration of the same rooftop at sunrise. The sky is painted in soft pink, peach, and orange gradients with wispy cirrus clouds stretching across. The city below is bathed in warm golden morning light, the old district slowly waking up with faint smoke from chimneys. The concrete rooftop floor is lit with a warm glow, the rusty railing catches the first light. A small potted plant in the corner. Peaceful, emotional, hopeful atmosphere, cinematic wide composition. High quality anime background art, Makoto Shinkai style dawn scene.
```

### Scene 10 — The Shop Morning
```
Anime illustration of the antique shop exterior in bright fresh morning sunlight. The front display window is now filled with colorful hand-drawn illustrations arranged beautifully behind the glass. The wooden front door stands open, warm interior light spills onto the cobblestone step. A new polished brass sign hangs above the entrance reading "Moonlight Exchange — Open." Potted plants flank the doorway, morning light creates soft lens flare. Clean fresh white and gold lighting, cheerful hopeful atmosphere, highly detailed environment art, Makoto Shinkai style, wallpaper quality.
```

---

## Video Prompts (LTX 2.3 + Prompt Relay)

**Separator:** `|` between segment prompts  
**Epsilon:** 0.001 (default) for smooth transitions; raise for harder cuts  
**Segment lengths:** Leave empty for even auto-distribution  

---

### Scene 1 — The Discovered Shop

**Global Prompt:**
> A 19-year-old anime girl Mei with messy chestnut hair and a faded blue ribbon wanders into a narrow old Japanese street at dusk, discovering a mysterious antique shop called "Moonlight Exchange." The atmosphere is warm and misty with amber street lamps. Mei stops, looks up at the glowing shop sign with curiosity, then slowly walks toward the entrance. Camera switches from a wide establishing shot to a close-up of her surprised expression, then to the shop sign.

**Segment Prompts:**
```
Wide establishing shot of a narrow old Japanese street at dusk, warm amber street lamps casting soft glow through evening mist, Mei in her cream cardigan walks into frame from the distance, head slightly down holding a sketchbook | Close-up of Mei's face as she looks up, warm amber eyes wide with curiosity, her expression soft and surprised, misty street background blurred | Medium shot of Mei walking toward the antique shop entrance, the hand-painted "Moonlight Exchange" sign glowing faintly above, hanging lanterns sway gently in the warm evening light | Mei (spoken line): "What a strange place... I've walked this street a hundred times and never seen it before."
```

---

### Scene 2 — First Meeting

**Global Prompt:**
> Mei steps inside the cozy cluttered antique shop filled with golden lamp light and vintage items. Inside, a tall dark-haired boy named Ren with cool grey eyes looks up from repairing a music box at the wooden counter. A chubby orange cat named Pudding stretches lazily on the counter. Mei looks around in wonder, then makes eye contact with Ren. Brief pause. Ren gives a small polite nod.

**Segment Prompts:**
```
Interior wide shot of the cozy antique shop, tall wooden shelves filled with vintage items, warm golden light from a brass lamp, Mei steps through the front door, the orange cat Pudding visible sleeping on the counter | Medium shot of Ren at the counter, dark messy hair, charcoal shirt with rolled sleeves, fingerless gloves, looking up from a small brass music box, cool grey eyes meeting Mei's gaze | Close-up of Mei's face, slightly nervous but curious expression, looking around at the shop's warm shelves and trinkets, soft golden light on her chestnut hair | Ren (spoken line, calm): "Welcome to Moonlight Exchange. We're not on any map." | Mei (spoken line, softly): "I can see it clearly enough..."
```

---

### Scene 3 — The Colored Key

**Global Prompt:**
> Mei stands at the antique shop counter and picks up an old brass key. She sees a soft pink glowing light radiating from the key that only she can perceive. Her expression becomes emotional. Ren watches her carefully from across the counter, noticing something unusual about her reaction. Close-up on the key, then on Mei's eyes, then on Ren's observant face.

**Segment Prompts:**
```
Medium shot of Mei standing at the wooden counter, surrounded by antique trinkets — a pocket watch, small glass vials, dried flowers, warm brass lamp light | Close-up of Mei's hand picking up an old brass key, her fingers wrap around it gently, her expression shifts from curiosity to something deeper | Extreme close-up of Mei's amber eyes, slightly teary, as if remembering something, soft pink light subtly reflecting in her irises (only she can see it) | Ren watching from across the counter, one hand resting on the music box, grey eyes narrowing slightly with interest and suspicion | Ren (spoken line, low voice): "That key... you've seen something, haven't you?" | Mei (spoken line, quickly): "No, I mean... I just... it feels warm."
```

---

### Scene 4 — Mei's Apartment

**Global Prompt:**
> Mei sits alone at her small wooden desk in her cozy apartment at sunset, surrounded by colorful illustrations pinned on the walls. She is sketching Ren from memory in her worn sketchbook, a half-empty boba tea cup beside her. She smiles softly while drawing, then pauses, touches the old brass key sitting on her desk, and looks out the window into the warm orange sunset.

**Segment Prompts:**
```
Wide shot of Mei's cozy apartment at sunset, walls covered in colorful illustrations, a small plant on the windowsill, warm orange light streaming through the window, Mei sits at her desk | Medium shot of Mei sketching in her worn sketchbook, pencil moving quickly, focused expression, a half-empty boba tea cup on the desk | Close-up of the sketch — it's a portrait of Ren with grey eyes and dark messy hair, still in progress, charcoal lines | Close-up of Mei's hand touching the old brass key on the desk, she pauses, looks up toward the window, soft smile on her lips | Mei (spoken line, whispering to herself): "Who are you... really?"
```

---

### Scene 5 — The Rooftop at Night

**Global Prompt:**
> Mei and Ren sit on the edge of a rooftop overlooking the old Japanese district at night. The city stretches below in a sea of tiny warm lights under a deep blue starlit sky with a crescent moon. Their legs dangle over the railing. They talk quietly about their reasons for being there. The mood is intimate and slightly awkward, almost close to confessing something. Camera moves between wide city view, medium two-shot, and individual close-ups.

**Segment Prompts:**
```
Wide establishing shot of the rooftop at night, deep blue starlit sky, crescent moon, the city stretches below in a sea of warm lights, two small silhouettes sit on the edge with legs dangling | Medium two-shot of Mei and Ren sitting side by side on the rooftop edge, backs to the camera, looking out at the city, quiet atmosphere, wind gently moves Mei's chestnut hair | Close-up of Mei's face in profile, moonlight on her features, she looks at Ren from the corner of her eye, slight blush, nervous smile | Close-up of Ren's face, looking straight at the city, calm expression, but his fingers tap restlessly on his knee | Ren (spoken line): "I come up here to hear the city. Everything down there has a story." | Mei (spoken line): "I see them. The stories. As colors." | Ren (spoken line, turning to look at her): "What do you mean?"
```

---

### Scene 6 — The Music Box

**Global Prompt:**
> Back at the antique shop, Ren shows Mei the music box he was repairing. He opens it, the tiny ballerina rotates, and a soft melody plays. Mei freezes — it's the same melody her mother used to hum. Her expression becomes deeply emotional, eyes filling with tears. Ren notices and watches her carefully. Close-ups on the music box, Mei's emotional face, and Ren's concerned look.

**Segment Prompts:**
```
Medium shot of Ren at the workbench, holding the opened brass music box in his hands, the tiny ballerina inside slowly rotating, warm lamp light | Close-up of the music box, intricate gears visible, the small ballerina figure spinning, golden light reflecting off the brass | Close-up of Mei's face — her eyes widen, then fill with tears, her hand covers her mouth, deeply emotional, as if remembering something precious | Medium shot of Ren watching Mei's reaction, his grey eyes softening with concern, he gently sets the music box down | Mei (spoken line, voice trembling): "This song... my mother used to sing it. How is this here?" | Ren (spoken line, quietly): "It came in without an owner. A year ago. I've been trying to fix it ever since."
```

---

### Scene 7 — Rainy Street

**Global Prompt:**
> Mei gets caught in heavy rain on her way to the shop on the old narrow street. She's standing outside with no umbrella, hugging her sketchbook to her chest, rain soaking her cream cardigan. Ren suddenly appears with a big black umbrella, holding it over both of them. They walk slowly down the wet street together, shoulders almost touching, reflections in the rain puddles. The mood is intimate and warm despite the cold rain.

**Segment Prompts:**
```
Wide shot of the old street in heavy rain, cobblestone street slick and reflective, rain streaking diagonally, Mei stands alone under the eaves of a building, hugging her sketchbook, rain soaked | Medium shot of Mei looking down the empty street, frustrated, rain dripping from her chestnut hair and blue ribbon, her cream cardigan darkened with water | Medium shot of Ren stepping into frame with a big black umbrella, tilting it over Mei, his dark hair already wet, a faint smile on his face | Two-shot from behind, Mei and Ren walking slowly down the rain-slicked street under the umbrella, shoulders almost touching, puddles reflecting the amber shop lights behind them | Ren (spoken line): "You're going to catch a cold. And your drawings will get ruined." | Mei (spoken line, soft laugh): "I walked past you three times. You were standing in the doorway this whole time." | Ren (spoken line): "Someone has to make sure you don't lose your way."
```

---

### Scene 8 — The Attic Discovery

**Global Prompt:**
> Mei and Ren explore the dusty attic of the antique shop. Shafts of golden afternoon light stream through a skylight. They find an old locked wooden chest with iron bands. Mei reaches into her pocket and pulls out the brass key she bought — it fits perfectly. The chest opens to reveal an old letter and a faded photograph of two teenagers who look like younger Ren and a girl. Both of them stare in silence.

**Segment Prompts:**
```
Wide shot of the dusty attic, dramatic golden light shafts through a skylight, dust motes floating, Mei and Ren walk through stacked trunks and covered furniture | Medium shot of Ren pushing aside a dust sheet, revealing an old locked wooden chest with iron bands, he looks puzzled | Close-up of Mei reaching into her cardigan pocket, pulling out the small brass key, her expression determined | Extreme close-up of the key sliding into the chest's lock, a soft metallic click, Mei's hand and Ren's hand both reach for the lid | Medium shot of the opened chest — an old yellowed letter and a faded black-and-white photograph of two smiling teenagers | Close-up of Mei and Ren's faces side by side — both staring at the photo in stunned silence, the two teenagers look exactly like younger Ren and a girl | Mei (spoken line, whispering): "That's you... isn't it?" | Ren (spoken line, voice barely audible): "And that was... someone I couldn't save."
```

---

### Scene 9 — The Confession

**Global Prompt:**
> Mei and Ren stand on the rooftop at sunrise, the sky painted in pink and peach gradients. They face each other and finally confess their secrets — Mei tells Ren she can see emotions as colors, and Ren tells her he can hear the memories of old objects when he touches them. The wind blows gently. After a pause, they finally hold hands. Emotional, vulnerable, warm lighting.

**Segment Prompts:**
```
Wide establishing shot of the rooftop at sunrise, pink and peach sky with wispy clouds, the city below in warm golden morning light, two figures stand facing each other near the railing | Medium two-shot of Mei and Ren facing each other, wind blowing through Mei's chestnut hair and Ren's dark hair, sunrise light wrapping around them | Close-up of Mei's face, eyes determined, tears in her eyes, speaking honestly for the first time | Close-up of Ren's face, guard completely dropped, grey eyes vulnerable and open, listening intently | Close-up of their hands — Mei reaches out, Ren hesitates for a fraction of a second, then wraps his fingers around hers | Mei (spoken line): "I see emotions as colors. Nostalgia is gold. Sadness is blue. And you, Ren... you're silver. But under it, there's so much red." | Ren (spoken line, voice breaking slightly): "I hear them. Every object I touch... it tells me its story. That music box... it was singing about being found. About you." | Mei (spoken line): "Then let's write a new story together."
```

---

### Scene 10 — New Morning

**Global Prompt:**
> The Moonlight Exchange shop in bright fresh morning sunlight. The front window display is now filled with Mei's colorful illustrations arranged beautifully. The wooden door is open. Ren stands in the doorway with Pudding the orange cat sitting beside him. Mei walks toward them from the street, holding a new brass sign that reads "Moonlight Exchange — Open." She hangs it above the door with a bright smile. Ren and Pudding watch. Cheerful, hopeful ending.

**Segment Prompts:**
```
Wide establishing shot of the shop exterior in bright morning sunlight, the front window now filled with colorful illustrations, warm light spilling from the open door, potted plants in the doorway | Medium shot of Ren standing in the shop doorway, charcoal shirt sleeves rolled, arms crossed with a small satisfied smile, Pudding the orange cat sits on the step beside him, one white paw raised | Medium shot of Mei walking up to the shop from the cobblestone path, holding a new polished brass sign, bright morning light on her face, she smiles confidently | Close-up of Mei's hands hanging the new brass sign above the door, it reads "Moonlight Exchange — Open," her blue ribbon catches the morning breeze | Wide final shot of the complete shop front, new sign gleaming, window full of color, Ren and Pudding in the doorway, Mei standing beside him with her sketchbook, all three silhouettes in the golden morning light | Ren (spoken line): "Open for business?" | Mei (spoken line, laughing): "Let's tell some stories." | Pudding (spoken meow, subtitle): "Nya~"
```

---

## Quick Reference

| Scene | Segments | Est. Duration | Key Action |
|---|---|---|---|
| 1 | 3 | ~20s | Mei discovers the shop |
| 2 | 3 | ~20s | First meeting, Ren + Pudding |
| 3 | 4 | ~20s | The key, pink light, tension |
| 4 | 4 | ~20s | Mei sketches Ren at home |
| 5 | 4 | ~20s | Rooftop night talk |
| 6 | 4 | ~20s | Music box, emotion |
| 7 | 4 | ~20s | Rain, umbrella, walk |
| 8 | 6 | ~20s | Attic, chest, photo reveal |
| 9 | 5 | ~20s | Sunrise confession, hold hands |
| 10 | 5 | ~20s | New morning, sign, happy ending |

**Total estimated video: ~3.5 minutes**

---

## Video Generation Pipeline

**Script:** `generate_video.py`
**Model:** LTX 2.3 (`ltx2/ltx-2.3-22b-dev.safetensors`)
**Method:** Prompt Relay (ComfyUI-PromptRelay)
**CLIP:** Gemma 3 12B + LTX 2.3 Text Projection
**Video VAE:** LTX23 Video VAE
**Default:** 25fps, 20s per scene, 768x512

```bash
python generate_video.py --list              # List scenes & status
python generate_video.py --scene 1           # Generate scene 1
python generate_video.py --scene 1-3         # Generate scenes 1-3
python generate_video.py --all               # Generate all 10 scenes
python generate_video.py --scene 1 --duration 15 --fps 25
```

Each scene uses its generated background image as the start frame for image-to-video generation.

---

*Created: 2026-05-03*  
*Model: Z-Anime (SeeSee21/Z-Anime) + LTX 2.3 Prompt Relay*
