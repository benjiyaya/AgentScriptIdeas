"""Quick test of the Moonlight Exchange LangGraph agent."""
import sys
sys.path.insert(0, ".")
from main import create_agent
from langchain_core.messages import HumanMessage

graph = create_agent()
state = {
    "messages": [HumanMessage(content="List all scenes and their current status.")],
    "scene_num": 0, "scene_name": "", "scene_config": {},
    "start_frame_path": "", "start_frame_filename": "",
    "video_output_path": "", "comfyui_prompt_id": "",
    "comfyui_status": "pending", "image_generated": False,
    "dashscope_task_id": "", "dashscope_status": "pending",
    "video_url": "", "video_downloaded": False,
    "seed": 0, "error": "", "created_at": "",
}
result = graph.invoke(state)
for msg in result["messages"]:
    if hasattr(msg, "content") and msg.content:
        print(msg.content)
