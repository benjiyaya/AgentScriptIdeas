"""
Creative Story Agent — Agent Entry Point

Delegates to story_agent.py for creative work.
This file is kept for backward compatibility with direct_pipeline.py imports.
"""

# Re-export for direct_pipeline.py
from .story_agent import PROJECTS_DIR, CURRENT_PROJECT_FILE
